"""Make a deterministic synthetic vowel fixture (not Japanese TTS)."""
import math, wave, struct
from pathlib import Path
rate=24000
samples=[]
for f1,f2 in [(730,1090),(270,2290),(300,870),(530,1840),(570,840)]*2:
 for i in range(int(rate*.35)):
  t=i/rate
  env=min(1,t/.025,(.35-t)/.04)
  v=0
  for harmonic in range(1,32):
   f=harmonic*120
   gain=math.exp(-((f-f1)/160)**2)+.6*math.exp(-((f-f2)/220)**2)+.08/harmonic
   v+=gain*math.sin(2*math.pi*f*t)
  samples.append(int(max(-1,min(1,v*.17*env))*32767))
 samples.extend([0]*int(rate*.1))
p=Path(__file__).resolve().parents[1]/'tests/fixtures/formants.wav'
with wave.open(str(p),'wb') as w:
 w.setnchannels(1);w.setsampwidth(2);w.setframerate(rate);w.writeframes(struct.pack('<'+'h'*len(samples),*samples))
print(p)
