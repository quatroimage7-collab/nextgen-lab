"""Strip unused texture/clothing data from the upstream CC0 MPFB avatar for point rendering.
Usage: python scripts/prepare-avatar.py SOURCE.glb public/avatars/mpfb.glb
"""
import json,struct,sys
from pathlib import Path
raw=Path(sys.argv[1]).read_bytes()
assert len(raw)==struct.unpack_from('<I',raw,8)[0], 'Incomplete GLB download'
n=struct.unpack_from('<I',raw,12)[0]
d=json.loads(raw[20:20+n]); binary=raw[28+n:]
kept=[i for i,m in enumerate(d['meshes']) if m.get('name') in ('base','high-poly')]
for node in d['nodes']:
 if 'mesh' in node:
  if node['mesh'] in kept: node['mesh']=kept.index(node['mesh'])
  else: del node['mesh']
d['meshes']=[d['meshes'][i] for i in kept]
used=set()
for mesh in d['meshes']:
 for p in mesh['primitives']:
  p['material']=0
  used.update(p['attributes'].values())
  if 'indices' in p: used.add(p['indices'])
  for target in p.get('targets',[]): used.update(target.values())
for skin in d.get('skins',[]):
 if 'inverseBindMatrices' in skin: used.add(skin['inverseBindMatrices'])
for anim in d.get('animations',[]):
 for s in anim['samplers']: used.update((s['input'],s['output']))
used=sorted(used); amap={old:new for new,old in enumerate(used)}
for mesh in d['meshes']:
 for p in mesh['primitives']:
  p['attributes']={k:amap[v] for k,v in p['attributes'].items()}
  if 'indices' in p:p['indices']=amap[p['indices']]
  p['targets']=[{k:amap[v] for k,v in t.items()} for t in p.get('targets',[])]
for skin in d.get('skins',[]):
 if 'inverseBindMatrices' in skin:skin['inverseBindMatrices']=amap[skin['inverseBindMatrices']]
for anim in d.get('animations',[]):
 for s in anim['samplers']:
  s['input']=amap[s['input']];s['output']=amap[s['output']]
d['accessors']=[d['accessors'][i] for i in used]
viewset={a['bufferView'] for a in d['accessors'] if 'bufferView' in a}
for a in d['accessors']:
 if 'sparse' in a:
  viewset.update((a['sparse']['indices']['bufferView'], a['sparse']['values']['bufferView']))
views=sorted(viewset);vmap={old:new for new,old in enumerate(views)}
newbin=bytearray();newviews=[]
for i in views:
 v=dict(d['bufferViews'][i]); start=v.get('byteOffset',0);newstart=len(newbin)
 newbin.extend(binary[start:start+v['byteLength']]);newbin.extend(b'\0'*(-len(newbin)%4))
 v['byteOffset']=newstart;newviews.append(v)
for a in d['accessors']:
 if 'bufferView' in a:a['bufferView']=vmap[a['bufferView']]
 if 'sparse' in a:
  for part in ('indices','values'):a['sparse'][part]['bufferView']=vmap[a['sparse'][part]['bufferView']]
d['bufferViews']=newviews;d['buffers']=[{'byteLength':len(newbin)}]
d['materials']=[{'name':'PointDepth','pbrMetallicRoughness':{'baseColorFactor':[1,1,1,1]}}]
for key in ('images','textures','samplers'):d.pop(key,None)
j=json.dumps(d,separators=(',',':')).encode();j+=b' '*(-len(j)%4)
result=struct.pack('<III',0x46546c67,2,12+8+len(j)+8+len(newbin))+struct.pack('<II',len(j),0x4e4f534a)+j+struct.pack('<II',len(newbin),0x004e4942)+newbin
Path(sys.argv[2]).write_bytes(result)
print('Prepared point avatar:',len(result),'bytes')
