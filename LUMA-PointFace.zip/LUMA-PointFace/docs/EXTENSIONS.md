# 次の拡張に向けた境界

カメラによる特徴観察・自動挨拶を実装しました。ロボットは未接続です。

## イベント

`src/extensions.js` の `agentEvents` は以下を発火します。

- `session.state`: `{ state }` — idle / connecting / listening / thinking / speaking
- `transcript.final`: `{ role, text }` — 完成した字幕
- `realtime.event`: Realtimeの受信イベント

機能を追加するコードはこのイベントを購読し、UI/音声処理の内部を直接操作しない構成にします。`RobotAdapter` は未接続エラーを返すスタブです。

## Webカメラ

`src/camera.js` の `CameraGreeter` が映像取得とJPEG生成を担当します。最大幅480px、data URL 44,000文字未満に縮小し、約12秒ごとに送信します。開始・停止はUIから明示的に行い、カメラトラックの切断、セッション終了、ページ終了時に解放します。

`src/realtime.js` の `observeImage` は `gpt-realtime` の out-of-band `response.create` を使用します。`conversation: "none"`、`output_modalities: ["text"]`、`metadata.topic: "camera"` で通常会話から分離します。結果はpeople/clothing/object/actionの限定列挙値として検証します。画像は会話履歴に加えず、人物の特徴の自由記述や識別子を保持しません。

`PresenceGate` は個人識別なしで挨拶を抑制します。人がいない結果が2回続くまで再挨拶せず、最短間隔60秒を適用します。通常会話中とユーザー発話後15秒は待ちます。撮影開始後にユーザーが話し始めた場合も、結果到着時に再確認して声かけを見送ります。カメラの開始世代が変わった結果は捨てます。

将来、高速な通行人の検出が必要ならPC内の人物検出と追跡を追加し、検出時だけ画像解析を呼ぶ構成に交換できます。現在はPC内の人物検出器や個人追跡は実装していません。

## Pupper V3 / ROS 2

Windowsのこのアプリと、Pupper側のROS 2ノードを分離します。

1. 会話側に許可された操作だけのtool schemaを追加。
2. ローカルサーバーが要求を検証し、独立した認証付きROS 2ゲートウェイへ送信。
3. ROS 2ノードが速度・継続時間を制限して指令をpublish。
4. 実機状態、タイムアウト、停止完了を会話側に戻す。

接続先トピックとコントローラーは実機の構成を確認して決めます。言語モデルに任意トピックへのpublishを直接許可せず、停止優先・指令の有効期限・通信断時の停止をゲートウェイに実装してください。ブラウザーの「返答を停止」は音声だけの停止であり、ロボットの非常停止とは別系統です。

このプロトタイプにはロボットへのネットワーク接続や自動運動コードは含まれていません。
