import { TalkingHead } from '@met4citizen/talkinghead/modules/talkinghead.mjs';
import { HeadAudio } from '../public/vendor/headaudio.mjs';
import { makePointFace } from './point-face.js';
import { createReferenceScreen } from './reference-screen.js';

export class Avatar {
  constructor(element) {
    this.element=element;
    const rig=document.createElement('div');rig.className='internal-rig';element.append(rig);
    this.head = new TalkingHead(rig, {
      lipsyncModules: [], cameraView: 'head', cameraDistance: 0.0,
      cameraY: 0.05, cameraRotateEnable: false, cameraZoomEnable: false,
      modelPixelRatio: Math.min(devicePixelRatio, 1.5), modelFPS: 30,
      modelMovementFactor: 0.35, avatarIdleEyeContact: 0.85,
      avatarIdleHeadMove: 0.18, lightAmbientIntensity: 1.8,
      lightDirectIntensity: 14, lightDirectColor: '#e4edf7',
      lightSpotIntensity: 5, lightSpotColor: '#8bcdbf', lightSpotTheta: 3.7,
    });
    this.audio = this.head.audioCtx;
    this.sources = new Set(); this.expressionTimer = null; this.audioGeneration = 0;
  }
  async load(onProgress) {
    this.reference=await createReferenceScreen(this.element,this.head);
    await this.head.showAvatar({ url: '/avatars/mpfb.glb', body: 'F', avatarMood: 'neutral' }, onProgress);
    this.pointFace = makePointFace(this.head);
    await this.audio.audioWorklet.addModule('/vendor/headworklet.mjs');
    this.lipsync = new HeadAudio(this.audio);
    await this.lipsync.loadModel('/vendor/model-en-mixed.bin');
    this.head.audioSpeechGainNode.connect(this.lipsync);
    this.lipsync.onvalue = (key, value) => {
      const target = this.head.mtAvatar[key];
      if (target) Object.assign(target, { newvalue: value, needsUpdate: true });
    };
    this.head.opt.update = dt => { this.lipsync.update(dt); };
    this.lipsync.onstarted = () => this.head.lookAtCamera(600);
  }
  async resume() { await this.audio.resume(); this.head.start(); }
  attach(stream) {
    const source = this.audio.createMediaStreamSource(stream);
    source.connect(this.head.audioAnalyzerNode); this.sources.add(source);
    return () => { source.disconnect(); this.sources.delete(source); };
  }
  async playFile(data) {
    const generation = this.audioGeneration;
    const buffer = await this.audio.decodeAudioData(data.slice(0));
    await this.resume();
    if (generation !== this.audioGeneration) return;
    const source = this.audio.createBufferSource(); source.buffer = buffer;
    source.connect(this.head.audioAnalyzerNode); this.sources.add(source);
    return new Promise(resolve => {
      source.onended = () => { source.disconnect(); this.sources.delete(source); resolve(); };
      source.start();
    });
  }
  stopAudio() {
    this.audioGeneration++;
    for (const s of this.sources) { try { s.stop?.(); } catch {} s.disconnect(); }
    this.sources.clear();
  }
  setExpression(name, autoReset = false) {
    this.reference?.expression(name);
    clearTimeout(this.expressionTimer);
    this.head.setMood(name === 'happy' ? 'happy' : 'neutral');
    for (const key of ['browInnerUp', 'eyeWideLeft', 'eyeWideRight', 'browDownLeft', 'headRotateZ']) this.head.setValue(key, null, 250);
    if (name === 'thinking') {
      this.head.setValue('browDownLeft', 0.25, 400);
      this.head.setValue('headRotateZ', 0.08, 500);
    }
    if (name === 'surprised') {
      this.head.setValue('browInnerUp', 0.65, 220);
      this.head.setValue('eyeWideLeft', 0.7, 220); this.head.setValue('eyeWideRight', 0.7, 220);
    }
    if (autoReset) this.expressionTimer = setTimeout(() => this.setExpression('neutral'), 3500);
  }
}
