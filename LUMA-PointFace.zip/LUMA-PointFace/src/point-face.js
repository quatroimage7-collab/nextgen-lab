import * as THREE from 'three';

// Surface samples retain the source mesh's morph targets and bone weights.
// Thus lips/blinks are geometry deformations, not a waveform overlay.
export function makePointFace(head) {
  const originals = [];
  head.scene.traverse(mesh => { if (mesh.isSkinnedMesh) originals.push(mesh); });
  const points = [];
  for (const mesh of originals) {
    const name = mesh.name.toLowerCase();
    const isBody = name === 'human' || name === 'body' || name === 'base' || mesh.material?.name === 'Human.body';
    if (!isBody) { mesh.visible = false; continue; }
    const source = mesh.geometry;
    const pos = source.attributes.position;
    const index = source.index;
    const triangles = [];
    const a = new THREE.Vector3(), b = new THREE.Vector3(), c = new THREE.Vector3(), ab = new THREE.Vector3(), ac = new THREE.Vector3();
    let total = 0;
    for (let i = 0; i < (index?.count || pos.count); i += 3) {
      const ids = [0, 1, 2].map(k => index ? index.getX(i + k) : i + k);
      a.fromBufferAttribute(pos, ids[0]); b.fromBufferAttribute(pos, ids[1]); c.fromBufferAttribute(pos, ids[2]);
      const y = (a.y + b.y + c.y) / 3;
      const x = (a.x + b.x + c.x) / 3;
      const z = (a.z + b.z + c.z) / 3;
      // Front facial mask only: no ears, eyeballs, skull rear, or neck.
      const jaw = 1.532 + 0.045 * Math.pow(Math.abs(x) / 0.076, 2);
      const eye = Math.pow((Math.abs(x) - 0.033) / 0.026, 2) + Math.pow((y - 1.651) / 0.018, 2);
      if (y < jaw || z < 0.080 || Math.abs(x) > 0.076 || eye < 1.1) continue;
      const area = ab.subVectors(b, a).cross(ac.subVectors(c, a)).length() * 0.5;
      const weight = 1;
      total += area * weight;
      triangles.push({ ids, upto: total });
    }
    if (!triangles.length || total === 0) { mesh.visible = false; continue; }
    const count = 18000;
    const geo = new THREE.BufferGeometry();
    const normals = new Float32Array(count * 3);
    const positions = new Float32Array(count * 3), skinIndices = new Uint16Array(count * 4), skinWeights = new Float32Array(count * 4), brightness = new Float32Array(count);
    const morphs = (source.morphAttributes.position || []).map(() => new Float32Array(count * 3));
    let seed = 1234567;
    const random = () => { seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0; return seed / 4294967296; };
    for (let n = 0; n < count; n++) {
      const target = random() * total;
      let lo = 0, hi = triangles.length - 1;
      while (lo < hi) { const mid = (lo + hi) >>> 1; if (triangles[mid].upto < target) lo = mid + 1; else hi = mid; }
      const ids = triangles[lo].ids;
      const r = Math.sqrt(random()), s = random(), weights = [1 - r, r * (1 - s), r * s];
      const bones = new Map();
      ids.forEach((id, k) => {
        const w = weights[k];
        for (let axis = 0; axis < 3; axis++) { positions[n * 3 + axis] += pos.array[id * 3 + axis] * w; normals[n * 3 + axis] += source.attributes.normal.array[id * 3 + axis] * w; }
        source.morphAttributes.position?.forEach((attr, m) => { for (let axis = 0; axis < 3; axis++) morphs[m][n * 3 + axis] += attr.array[id * 3 + axis] * w; });
        for (let j = 0; j < 4; j++) {
          const bone = source.attributes.skinIndex.array[id * 4 + j];
          bones.set(bone, (bones.get(bone) || 0) + source.attributes.skinWeight.array[id * 4 + j] * w);
        }
      });
      const strongest = [...bones].sort((x, y) => y[1] - x[1]).slice(0, 4);
      const sum = strongest.reduce((v, p) => v + p[1], 0);
      strongest.forEach(([id, weight], j) => { skinIndices[n * 4 + j] = id; skinWeights[n * 4 + j] = weight / sum; });
      brightness[n] = 0.48 + random() * 0.40;
    }
    geo.setAttribute('normal', new THREE.BufferAttribute(normals, 3));
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geo.setAttribute('skinIndex', new THREE.BufferAttribute(skinIndices, 4));
    geo.setAttribute('skinWeight', new THREE.BufferAttribute(skinWeights, 4));
    geo.setAttribute('brightness', new THREE.BufferAttribute(brightness, 1));
    geo.morphAttributes.position = morphs.map(values => new THREE.BufferAttribute(values, 3));
    geo.morphTargetsRelative = source.morphTargetsRelative;
    const material = new THREE.ShaderMaterial({
      uniforms: { pointSize: { value: 1.8 }, tint: { value: new THREE.Color('#c2e9ff') }, time: { value: 0 } },
      vertexShader: `
        #include <common>
        #include <morphtarget_pars_vertex>
        #include <skinning_pars_vertex>
        attribute float brightness;
        uniform float pointSize;
        uniform float time;
        varying float vLight;
        void main() {
          #include <begin_vertex>
          #include <morphtarget_vertex>
          #include <skinbase_vertex>
          vec3 objectNormal = normal;
          #include <skinnormal_vertex>
          #include <skinning_vertex>
          vec4 mv = modelViewMatrix * vec4(transformed, 1.0);
          gl_Position = projectionMatrix * mv;
          gl_PointSize = clamp(pointSize * 2.5 / -mv.z, 1.0, 3.4);
          vec3 n = normalize(normalMatrix * objectNormal);
          float lighting = 0.55 + 0.45 * max(dot(n, normalize(vec3(-0.5, 0.7, 1.0))), 0.0);
          float jaw = 1.532 + 0.045 * pow(abs(position.x) / 0.076, 2.0);
          float eye = pow((abs(position.x) - 0.033) / 0.026, 2.0) + pow((position.y - 1.651) / 0.018, 2.0);
          float mask = smoothstep(jaw, jaw + 0.010, position.y)
            * (1.0 - smoothstep(0.069, 0.076, abs(position.x)))
            * smoothstep(0.080, 0.093, position.z)
            * smoothstep(1.05, 1.35, eye);
          vLight = mask * brightness * lighting * (0.90 + 0.10 * sin(time * 0.8 + position.y * 18.0));
        }`,
      fragmentShader: `
        uniform vec3 tint;
        varying float vLight;
        void main() {
          float r = length(gl_PointCoord - vec2(0.5));
          if(r > 0.5) discard;
          float alpha = (1.0 - smoothstep(0.23, 0.5, r)) * vLight;
          gl_FragColor = vec4(tint, alpha);
        }`,
      transparent: true, depthWrite: false, depthTest: true, blending: THREE.AdditiveBlending,
    });
    const cloud = new THREE.Points(geo, material);
    // Three.js enables its native morph/skin shader paths from these fields.
    cloud.isSkinnedMesh = true; cloud.skeleton = mesh.skeleton;
    cloud.bindMatrix = mesh.bindMatrix; cloud.bindMatrixInverse = mesh.bindMatrixInverse;
    cloud.morphTargetInfluences = mesh.morphTargetInfluences;
    cloud.morphTargetDictionary = mesh.morphTargetDictionary;
    cloud.frustumCulled = false; cloud.renderOrder = 5;
    mesh.add(cloud); points.push(cloud);
    // Invisible depth surface hides back-of-head particles and preserves the face silhouette.
    const depth = new THREE.MeshBasicMaterial({ colorWrite: false, depthWrite: true, polygonOffset: true, polygonOffsetFactor: 1, polygonOffsetUnits: 2 });
    mesh.material = depth; mesh.renderOrder = 0;
  }
  return {
    count: points.reduce((sum, p) => sum + p.geometry.attributes.position.count, 0),
    update: time => points.forEach(p => { p.material.uniforms.time.value = time; }),
  };
}
