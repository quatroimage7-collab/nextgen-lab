import * as THREE from 'three';

// All visible dots are real 3D points. No photograph, image plane or UV warp.
export async function createReferenceScreen(element, head) {
  const renderer = new THREE.WebGLRenderer({antialias:true,alpha:false});
  renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));
  renderer.setClearColor(0x020810,1);
  renderer.domElement.className='reference-canvas';element.append(renderer.domElement);
  const scene=new THREE.Scene();
  const camera=new THREE.PerspectiveCamera(48,1,.1,50);camera.position.z=6.8;
  const reduced=matchMedia('(prefers-reduced-motion: reduce)');
  const uniforms={time:{value:0},sphereScale:{value:1},bounceY:{value:0},energy:{value:0},pixels:{value:1}};
  let seed=5328;
  const rand=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
  const resources=[];
  function points(count,kind,make){
    const positions=new Float32Array(count*3),seeds=new Float32Array(count);
    for(let i=0;i<count;i++){const p=make(i,count);positions.set(p,i*3);seeds[i]=rand();}
    const geometry=new THREE.BufferGeometry();
    geometry.setAttribute('position',new THREE.BufferAttribute(positions,3));
    geometry.setAttribute('seed',new THREE.BufferAttribute(seeds,1));
    const material=new THREE.ShaderMaterial({
      uniforms:{...uniforms,kind:{value:kind}},transparent:true,depthWrite:false,blending:THREE.AdditiveBlending,
      vertexShader:`
        attribute float seed;
        uniform float time,sphereScale,bounceY,energy,pixels,kind;
        varying vec3 tint; varying float opacity;
        void main(){
          vec3 p=position;
          float phase=seed*62.83185;
          if(kind<.5){
            // Each particle has its own angular velocity and radial phase.
            // Differential flow continually changes the shell's arrangement.
            float r=length(p);
            float lat=asin(clamp(p.y/r,-1.,1.));
            float longitude=atan(p.z,p.x);
            longitude+=time*(.10+.055*sin(lat*4.)+.035*seed);
            lat+=.020*sin(time*.8+phase)+.012*sin(longitude*7.+time*.6);
            float ripple=sin(longitude*9.+lat*6.+time*1.25+phase*.18);
            float fine=sin(time*1.9+phase);
            r*=sphereScale*(1.+(.013+.04*energy)*ripple+.009*fine);
            p=vec3(cos(lat)*cos(longitude),sin(lat),cos(lat)*sin(longitude))*r;
            p.y+=bounceY*5.7;
            float front=smoothstep(-1.5,1.5,p.z);
            float rim=pow(1.-abs(p.z)/max(r,.01),3.);
            tint=mix(vec3(.04,.30,.66),vec3(.68,.92,1.),front);
            tint+=vec3(.1,.14,.16)*rim;
            opacity=(.23+.85*front+.25*rim)*(.78+.22*sin(phase+time*.9));
          }else if(kind<1.5){
            // Background dots drift independently in depth and across lanes.
            p.z=-13.+mod(position.z+13.+time*(.12+.3*seed),17.);
            p.x+=.24*sin(time*(.16+.09*seed)+phase);
            p.y+=.20*cos(time*(.21+.07*seed)+phase*1.7);
            tint=mix(vec3(.045,.30,.55),vec3(.25,.74,1.),seed);
            opacity=(.23+.8*seed)*smoothstep(-13.,-8.,p.z)*(1.-smoothstep(2.,4.,p.z));
          }else{
            float a=time*(.018+.014*seed);
            p.xy=mat2(cos(a),-sin(a),sin(a),cos(a))*p.xy;
            p.z+=.035*sin(time*.65+phase);
            tint=vec3(.06,.40,.70);opacity=.40+.18*sin(phase+time*.35);
          }
          vec4 mv=modelViewMatrix*vec4(p,1.);
          gl_Position=projectionMatrix*mv;
          float size=kind<.5 ? 1.7+seed*2.8 : (kind>1.5?1.8+seed*1.4:1.+pow(seed,4.)*8.);
          gl_PointSize=clamp(size*pixels*6.8/max(.6,-mv.z),.65,12.);
          tint*=kind<.5?.94:1.27;
          opacity*=1.+energy*(kind<.5?.16:.04);
        }`,
      fragmentShader:`
        varying vec3 tint; varying float opacity;
        void main(){
          float r=length(gl_PointCoord-.5)*2.;if(r>1.)discard;
          float core=exp(-r*r*3.8);float halo=.23*(1.-r);
          gl_FragColor=vec4(tint,opacity*(core+halo));
        }`,
    });
    const object=new THREE.Points(geometry,material);object.frustumCulled=false;scene.add(object);resources.push(geometry,material);return object;
  }
  const sphereCount=18000,backgroundCount=12600,ringCount=1500;
  points(sphereCount,0,(i,n)=>{
    const y=1-2*(i+.5)/n,angle=i*Math.PI*(3-Math.sqrt(5));
    const radius=1.48*(i%9===0?.84+rand()*.12: .984+rand()*.032);
    const h=Math.sqrt(1-y*y);return [radius*h*Math.cos(angle),radius*y,radius*h*Math.sin(angle)];
  });
  points(backgroundCount,1,()=>{
    // Perspective rays form a digital space without raster background artwork.
    const lane=Math.floor(rand()*84),angle=lane*Math.PI*2/84;
    const radius=1.4+rand()*12;
    return [Math.cos(angle)*radius,Math.sin(angle)*radius*.70,-13+rand()*17];
  });
  points(ringCount,2,(i)=>{
    const ring=i%3,a=Math.floor(i/3)/500*Math.PI*2,r=2.35+ring*.35;
    return [Math.cos(a)*r,Math.sin(a)*r,-1.8-ring*.2];
  });
  const resize=()=>{const w=element.clientWidth,h=element.clientHeight;renderer.setSize(w,h);camera.aspect=w/h;
    // Preserve the sphere on portrait screens too.
    camera.position.z=w/h<1?6.8/(w/h):6.8;camera.updateProjectionMatrix();uniforms.pixels.value=renderer.getPixelRatio()*Math.min(h/810,1.5);};
  const observer=new ResizeObserver(resize);observer.observe(element);resize();
  let amount=0,time=0,bouncePhase=0,last=performance.now();
  const samples=new Float32Array(head.audioAnalyzerNode.fftSize);
  const screen={
    update(){
      const now=performance.now(),dt=Math.min(.1,(now-last)/1000);last=now;
      head.audioAnalyzerNode.getFloatTimeDomainData(samples);
      const rms=Math.sqrt(samples.reduce((sum,v)=>sum+v*v,0)/samples.length);
      const target=Math.min(1,Math.max(0,rms-.005)*7);
      amount+=(target-amount)*(1-Math.exp(-dt/(target>amount?.065:.24)));
      if(!reduced.matches){time+=dt;bouncePhase+=dt*(1.8+amount*2.4);}
      uniforms.time.value=time;
      uniforms.bounceY.value=reduced.matches?0:(.016+.049*amount)*(.5-.5*Math.cos(bouncePhase));
      uniforms.sphereScale.value=reduced.matches?1:1+.03*Math.sin(time*.85)+.32*amount;
      // Reduced motion also disables local radial waves driven by speech.
      uniforms.energy.value=reduced.matches?0:amount;
      renderer.render(scene,camera);
    },
    expression(){},get mouthAmount(){return amount;},get audioEnergy(){return amount;},
    get bounceY(){return uniforms.bounceY.value;},get sphereScale(){return uniforms.sphereScale.value;},get ambientTime(){return time;},
    get particleCounts(){return {sphere:sphereCount,background:backgroundCount,rings:ringCount};},
  };
  let frame;const animate=()=>{if(!document.hidden)screen.update();else last=performance.now();frame=requestAnimationFrame(animate);};animate();
  window.addEventListener('pagehide',()=>{cancelAnimationFrame(frame);observer.disconnect();resources.forEach(r=>r.dispose());renderer.dispose();},{once:true});
  return screen;
}
