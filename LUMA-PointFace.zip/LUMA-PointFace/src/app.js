import { CameraGreeter } from './camera.js';
import { Avatar } from './avatar.js';
import { RealtimeConnection } from './realtime.js';
import { agentEvents } from './extensions.js';
import { initPanels } from './panels.js';

const $ = id => document.getElementById(id);
let camera, lastHumanSpeech = 0, humanSpeaking = false;
let avatar, connection, config, ready = false, state = 'idle', muted = false, testing = false;
let micNode, micAnalyser, startTime = 0, noticeTimer, testStream, recorder, testTimer, testGeneration = 0;
const messages = new Map();
const labels = { idle: '待機中', connecting: '接続しています…', listening: '聞いています', thinking: '考えています', speaking: '話しています', testing: 'ローカルテスト中' };
function notice(text) {
  clearTimeout(noticeTimer); $('notice').textContent = text; $('notice').hidden = false;
  noticeTimer = setTimeout(() => { $('notice').hidden = true; }, 18000);
}
function caption(label, text) { $('captionLabel').textContent = label; $('caption').textContent = text; }
function changeState(next) {
  state = next; $('status').textContent = labels[next] || next;
  document.body.dataset.sessionState=next;
  const connected = connection?.connected || false;
  const busy = next === 'connecting' || connected;
  $('statusDot').classList.toggle('on', connected);
  $('connect').textContent = busy ? (next === 'connecting' ? '接続をキャンセル' : '会話を終了') : '◉  会話をはじめる';
  $('connect').classList.toggle('stop', busy);
  $('connect').disabled = !ready || testing;
  $('mute').disabled = !connected; $('interrupt').disabled = !connected;
  $('textInput').disabled = !connected; $('send').disabled = !connected;
  $('recordTest').disabled = !ready || busy || testing; $('audioFile').disabled = !ready || busy || testing;
  if (next === 'thinking') avatar?.setExpression('thinking');
  if (next === 'listening' || next === 'idle') avatar?.setExpression('neutral');
  if (next === 'idle') {
    camera?.stop(); connection?.cancelCamera(); humanSpeaking = false;
    startTime = 0; muted = false; $('mute').textContent = 'マイクOFF'; $('micText').textContent = '未接続';
  }
  if (connected && !startTime) startTime = Date.now();
  agentEvents.emit('session.state', { state: next });
}
function entry(id, role, text, append = false) {
  $('empty')?.remove();
  let row = messages.get(id);
  if (!row) {
    const el = document.createElement('div'); el.className = `message ${role}`;
    const label = document.createElement('div'); label.className = 'message-label'; label.textContent = role === 'user' ? 'YOU' : 'LUMA';
    const p = document.createElement('p'); el.append(label, p); $('transcript').append(el);
    row = { el, p, text: '', role }; messages.set(id, row);
    if (messages.size > 200) { const first = messages.keys().next().value; messages.get(first).el.remove(); messages.delete(first); }
  }
  row.text = append ? row.text + text : text; row.p.textContent = row.text;
  $('transcript').scrollTop = $('transcript').scrollHeight;
  caption(role === 'user' ? 'YOU' : 'LUMA', row.text);
}
function onEvent(event) {
  const type = event.type;
  if (type === 'input_audio_buffer.speech_started') { humanSpeaking = true; lastHumanSpeech = Date.now(); }
  if (type === 'input_audio_buffer.speech_stopped') { humanSpeaking = false; lastHumanSpeech = Date.now(); }
  if (type === 'input_audio_buffer.speech_started') { changeState('listening'); caption('YOU', '聞いています…'); }
  if (type === 'input_audio_buffer.speech_stopped') changeState('thinking');
  if (type === 'response.created') changeState('thinking');
  if (type === 'output_audio_buffer.started') { changeState('speaking'); avatar.setExpression('neutral'); }
  if (type === 'output_audio_buffer.stopped' || type === 'output_audio_buffer.cleared') changeState('listening');
  if (type === 'conversation.item.input_audio_transcription.delta') entry(event.item_id, 'user', event.delta, true);
  if (type === 'conversation.item.input_audio_transcription.completed') { entry(event.item_id, 'user', event.transcript); agentEvents.emit('transcript.final', { role: 'user', text: event.transcript }); }
  if (type === 'conversation.item.input_audio_transcription.failed') notice('字幕の認識に失敗しました。もう一度お話しください。');
  if (type === 'response.output_audio_transcript.delta' || type === 'response.audio_transcript.delta') {
    entry(event.item_id || event.response_id, 'assistant', event.delta, true);
  }
  if (type === 'response.output_audio_transcript.done' || type === 'response.audio_transcript.done') {
    entry(event.item_id || event.response_id, 'assistant', event.transcript);
    if (/嬉し|うれし|ありがとう|楽し/.test(event.transcript)) avatar.setExpression('happy', true);
    else if (/驚|びっくり/.test(event.transcript)) avatar.setExpression('surprised', true);
    agentEvents.emit('transcript.final', { role: 'assistant', text: event.transcript });
  }
  if (type === 'response.done' && event.response?.status === 'failed') { changeState('listening'); notice('返答生成に失敗しました。APIの利用制限を確認して再試行してください。'); }
  if (type === 'error') notice(`会話エラー: ${event.error?.message || '再接続してください。'}`);
}
function setMic(stream) {
  micNode?.disconnect(); micNode = null; micAnalyser = null;
  if (stream) { micNode = avatar.audio.createMediaStreamSource(stream); micAnalyser = avatar.audio.createAnalyser(); micAnalyser.fftSize = 256; micNode.connect(micAnalyser); }
  $('micText').textContent = stream ? '入力中' : '未接続';
}
setInterval(() => {
  let value = 0;
  if (micAnalyser) { const data = new Float32Array(micAnalyser.fftSize); micAnalyser.getFloatTimeDomainData(data); value = Math.sqrt(data.reduce((s, v) => s + v * v, 0) / data.length); }
  $('micLevel').style.width = `${Math.min(100, value * 450)}%`;
  const sec = startTime ? Math.floor((Date.now() - startTime) / 1000) : 0;
  $('sessionClock').textContent = `${String(Math.floor(sec / 60)).padStart(2, '0')}:${String(sec % 60).padStart(2, '0')}`;
}, 100);

$('settingsButton').onclick = () => $('settings').showModal();
$('applySettings').onclick = () => $('settings').close();
$('diagnosticsButton').onclick = () => $('diagnostics').showModal();
$('connect').onclick = async () => {
  if (state === 'connecting' || connection.connected) { connection.close(); caption('SESSION ENDED', 'また、いつでも話しかけてください。'); return; }
  if (!config.hasKey && !$('apiKey').value.trim()) { $('settings').showModal(); $('apiKey').focus(); return; }
  $('notice').hidden = true;
  const key = $('apiKey').value.trim(); $('apiKey').value = '';
  await connection.connect(config, key, $('model').value, $('voice').value);
};
$('mute').onclick = () => { muted = !muted; connection.mute(muted); $('mute').textContent = muted ? 'マイクON' : 'マイクOFF'; $('micText').textContent = muted ? 'ミュート' : '入力中'; $('mute').setAttribute('aria-pressed', String(muted)); };
$('interrupt').onclick = () => { connection.interrupt(); avatar.setExpression('neutral'); };
$('clear').onclick = () => { messages.clear(); $('transcript').replaceChildren(); caption('TRANSCRIPT CLEARED', '字幕を消去しました。接続中の会話の文脈は継続します。'); };
$('textForm').onsubmit = event => {
  event.preventDefault(); const text = $('textInput').value.trim(); if (!text || !connection.connected) return;
  lastHumanSpeech = Date.now(); connection.sendText(text); entry(crypto.randomUUID(), 'user', text); $('textInput').value = '';
};
document.querySelectorAll('[data-mood]').forEach(button => { button.onclick = () => { avatar?.setExpression(button.dataset.mood, true); $('diagnostics').close(); }; });

function stopTest() {
  testGeneration++; clearTimeout(testTimer);
  if (recorder?.state === 'recording') recorder.stop();
  testStream?.getTracks().forEach(t => t.stop()); testStream = null;
  avatar?.stopAudio(); setMic(null); testing = false; changeState('idle');
}
async function playTest(data, generation) {
  if (generation !== testGeneration) return;
  $('diagnostics').close(); caption('LOCAL AUDIO TEST', 'テスト音声を再生しています。声に合わせて球体が膨らみます。');
  await avatar.playFile(data);
  if (generation !== testGeneration) return;
  caption('TEST COMPLETE', '音声・球体アニメーションのテストが終わりました。'); $('testStatus').textContent = 'テスト完了。実際の会話は「会話をはじめる」から接続します。';
}
$('recordTest').onclick = async () => {
  if (testing || connection.connected || state === 'connecting') return;
  testing = true; changeState('testing'); const generation = ++testGeneration;
  try {
    await avatar.resume();
    const stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true }, video: false });
    if (generation !== testGeneration) { stream.getTracks().forEach(t => t.stop()); return; }
    testStream = stream; setMic(stream); const chunks = [];
    recorder = new MediaRecorder(stream); recorder.ondataavailable = event => { if (event.data.size) chunks.push(event.data); };
    const recorded = new Promise(resolve => { recorder.onstop = resolve; });
    recorder.start(); $('testStatus').textContent = '録音中…4秒間、日本語で話してください。';
    testTimer = setTimeout(() => { if (recorder.state === 'recording') recorder.stop(); }, 4000);
    await recorded; stream.getTracks().forEach(t => t.stop()); setMic(null);
    const data = await new Blob(chunks, { type: recorder.mimeType }).arrayBuffer(); await playTest(data, generation);
  } catch (e) { notice(e.name === 'NotAllowedError' ? 'マイクの利用を許可してください。' : `テストできませんでした: ${e.message}`); }
  finally { if (generation === testGeneration) stopTest(); }
};
$('audioFile').onchange = async event => {
  const file = event.target.files[0]; if (!file) return;
  if (file.size > 20 * 1024 * 1024) { notice('テスト音声は20MB以下にしてください。'); event.target.value = ''; return; }
  testing = true; changeState('testing'); const generation = ++testGeneration;
  try { await playTest(await file.arrayBuffer(), generation); } catch { notice('この音声を再生できません。WAVまたはMP3をお試しください。'); }
  finally { if (generation === testGeneration) stopTest(); event.target.value = ''; }
};
window.addEventListener('pagehide', () => { camera?.stop(); connection?.close(); stopTest(); });
window.addEventListener('keydown', event => { if (event.key === 'Escape' && testing) { stopTest(); caption('TEST STOPPED', 'テストを停止しました。'); } });

async function boot() {
  try {
    if (!navigator.mediaDevices || !window.RTCPeerConnection || !window.AudioWorkletNode) throw new Error('EdgeまたはChromeで http://127.0.0.1:8787 を開いてください。');
    const response = await fetch('/api/config'); if (!response.ok) throw new Error('ローカルサーバーに接続できません。'); config = await response.json();
    if (config.hasKey) $('keyHelp').textContent = '.envのAPIキーを利用できます。ここに入力すると今回だけ上書きします。';
    avatar = new Avatar($('avatar'));
    await avatar.load(event => { if (event.lengthComputable) $('loadText').textContent = `球体を準備しています… ${Math.round(event.loaded / event.total * 100)}%`; });
    connection = new RealtimeConnection({ avatar, onEvent, onState: changeState, onError: notice, onMic: setMic });
    ready = true; $('cameraToggle').disabled = false; $('loading').hidden = true; changeState('idle');
    document.documentElement.dataset.ready = 'true';
  } catch (error) { $('loadText').textContent = `起動できませんでした: ${error.message}`; document.querySelector('.spinner').hidden = true; notice('START-WINDOWS.cmdから起動し、Edge/Chromeのグラフィックアクセラレーションを有効にしてください。'); }
}
camera = new CameraGreeter({
  video: $('cameraPreview'), observe: frame => connection.observeImage(frame),
  greet: text => connection.greetFromCamera(text),
  canObserve: () => !connection?.connected ? '会話を接続すると画像の送信が始まります。' : connection.model !== 'gpt-realtime' ? '接続設定で「Realtime · カメラ対応」を選び、会話を接続し直してください。' : humanSpeaking || connection.activeResponse || state !== 'listening' || Date.now() - lastHumanSpeech < 15000 ? '会話中 · 声かけを待っています' : '',
  canGreet: () => connection?.connected && !connection.activeResponse && !humanSpeaking && state === 'listening' && Date.now() - lastHumanSpeech >= 15000,
  status: text => { $('cameraStatus').textContent = text; },
  onActive: active => {
    $('cameraToggle').textContent = active ? 'カメラを停止' : 'カメラを開始';
    $('cameraToggle').setAttribute('aria-pressed', String(active));
    $('cameraIndicator').hidden = !active; $('cameraPreview').hidden = !active; $('cameraCheck').disabled = !active;
  },
});
const stopCamera = () => { camera.stop(); connection?.cancelCamera(); };
$('cameraToggle').onclick = () => camera.active || camera.starting ? stopCamera() : camera.start();
$('cameraStop').onclick = stopCamera;
$('cameraCheck').onclick = () => camera.check();
initPanels();
boot();

// Read-only diagnostics for local troubleshooting and automated verification.
export function diagnosticSnapshot() {
  return { ready, state, cameraActive: camera?.active || false, cameraBusy: camera?.busy || false, cameraTracks: camera?.stream?.getTracks().map(t => t.readyState) || [], renderedMouth: avatar?.reference?.mouthAmount || 0, ambientTime: avatar?.reference?.ambientTime || 0, displayMode: "particles-3d", particleCounts: avatar?.reference?.particleCounts, sphereScale: avatar?.reference?.sphereScale || 1, bounceY: avatar?.reference?.bounceY || 0, audioEnergy: avatar?.reference?.audioEnergy || 0, connected: connection?.connected || false, pointCount: avatar?.pointFace?.count || 0, audioState: avatar?.audio.state, sourceCount: avatar?.sources.size || 0, micTracks: connection?.stream?.getTracks().map(t => ({enabled:t.enabled, state:t.readyState})) || [], visemes: Object.fromEntries(Object.entries(avatar?.head.mtAvatar || {}).filter(([key]) => key.startsWith("viseme_")).map(([key,value]) => [key,value.value])) };
}
