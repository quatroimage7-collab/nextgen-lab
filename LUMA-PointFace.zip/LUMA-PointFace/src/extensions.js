// Stable seam for future camera observations and a separate ROS 2 gateway.
// No robot or camera access is enabled in this prototype.
export class AgentEvents extends EventTarget {
  emit(type, detail) { this.dispatchEvent(new CustomEvent(type, { detail })); }
}
export const agentEvents = new AgentEvents();
export class RobotAdapter {
  async execute() { throw new Error('ROS 2ゲートウェイは未接続です。'); }
  async stop() { throw new Error('ROS 2ゲートウェイは未接続です。'); }
}
