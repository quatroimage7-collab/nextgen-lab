// Only allow visible, non-identifying observations across the vision boundary.
export const COLORS = { blue: '青い', white: '白い', black: '黒い', red: '赤い', green: '緑の', yellow: '黄色い', gray: 'グレーの', other: '', unknown: '' };
export function validateObservation(value) {
  if (!value || !['none', 'one', 'multiple', 'uncertain'].includes(value.people)
    || !Object.hasOwn(COLORS, value.clothing)
    || !['umbrella', 'bag', 'none', 'unknown'].includes(value.object)
    || !['waving', 'walking', 'standing', 'unknown'].includes(value.action)) throw new Error('画像の判定を確認できませんでした。次回もう一度確認します。');
  return { people: value.people, clothing: value.clothing, object: value.object, action: value.action };
}
export function greetingFor(o) {
  if (o.action === 'waving') return 'こんにちは、ルマです。手を振ってくださってありがとうございます。少しお話ししませんか？';
  if (o.object === 'umbrella') return 'こんにちは、ルマです。傘をお持ちですね。よかったら少しお話ししませんか？';
  if (o.object === 'bag') return 'こんにちは、ルマです。バッグをお持ちですね。よかったら少しお話ししませんか？';
  if (COLORS[o.clothing]) return `こんにちは、ルマです。${COLORS[o.clothing]}お洋服が見えました。よかったら少しお話ししませんか？`;
  return 'こんにちは、ルマです。よかったら少しお話ししませんか？';
}
export class PresenceGate {
  constructor() { this.armed = true; this.emptyCount = 0; this.lastGreeting = -Infinity; }
  observe(o, now) {
    if (o.people === 'none') { this.emptyCount++; if (this.emptyCount >= 2) this.armed = true; return false; }
    this.emptyCount = 0;
    return o.people === 'one' && this.armed && now - this.lastGreeting >= 60000;
  }
  greeted(now) { this.armed = false; this.lastGreeting = now; }
}
export class CameraGreeter {
  constructor({ video, observe, greet, canObserve, canGreet, status, onActive }) {
    Object.assign(this, { video, observe, greet, canObserve, canGreet, status, onActive });
    this.generation = 0; this.stream = null; this.starting = false; this.busy = false; this.gate = new PresenceGate();
    this.canvas = document.createElement('canvas');
  }
  get active() { return !!this.stream; }
  async start() {
    if (this.active || this.starting) return;
    const generation = ++this.generation; this.starting = true; this.onActive(true);
    this.status('カメラの使用許可を待っています…');
    let timeout;
    try {
      const requested = navigator.mediaDevices.getUserMedia({ video: { width: { ideal: 640 }, height: { ideal: 360 }, facingMode: 'user' }, audio: false });
      requested.then(s => { if (generation !== this.generation) s.getTracks().forEach(t => t.stop()); }, () => {});
      const stream = await Promise.race([requested, new Promise((_, reject) => { timeout = setTimeout(() => reject(new Error('カメラの許可を確認できません。サイト設定を確認して再試行してください。')), 20000); })]);
      if (generation !== this.generation) { stream.getTracks().forEach(t => t.stop()); return; }
      this.stream = stream; this.video.srcObject = stream;
      stream.getVideoTracks().forEach(t => t.addEventListener('ended', () => { if (generation === this.generation) { this.stop(); this.status('カメラが切断されました。'); } }));
      await this.video.play();
      if (generation !== this.generation) return;
      this.starting = false; this.status('カメラON · 接続すると画像を確認します');
      this.timer = setInterval(() => this.check(), 12000); this.check();
    } catch (e) {
      if (generation !== this.generation) return;
      this.stop(); this.status(e.name === 'NotAllowedError' ? 'カメラの使用が許可されていません。Edge/Chromeのサイト設定をご確認ください。' : e.name === 'NotFoundError' ? 'カメラが見つかりません。USBカメラなどを接続してください。' : `カメラを開始できません: ${e.message}`);
    } finally { clearTimeout(timeout); }
  }
  snapshot() {
    if (this.video.readyState < 2 || !this.video.videoWidth) return null;
    // Bound data-channel payload size; no image files, object URLs or local storage.
    let width = Math.min(480, this.video.videoWidth);
    for (let attempt = 0; attempt < 4; attempt++) {
      this.canvas.width = width; this.canvas.height = Math.max(1, Math.round(width * this.video.videoHeight / this.video.videoWidth));
      this.canvas.getContext('2d').drawImage(this.video, 0, 0, this.canvas.width, this.canvas.height);
      const data = this.canvas.toDataURL('image/jpeg', 0.45);
      if (data.length < 44000) return data;
      width = Math.floor(width * 0.7);
    }
    return null;
  }
  async check() {
    if (!this.active || this.busy) return;
    const reason = this.canObserve(); if (reason) { this.status(reason); return; }
    const frame = this.snapshot(); if (!frame) { this.status('カメラ映像の準備を待っています…'); return; }
    const generation = this.generation; this.busy = true; this.status('画像を確認しています…');
    try {
      const result = validateObservation(await this.observe(frame));
      if (generation !== this.generation) return;
      const candidate = this.gate.observe(result, Date.now());
      const labels = { none: '人は映っていません', one: '1人を検出', multiple: '複数人のため声かけを見送ります', uncertain: '判定が不確かです' };
      this.status(`${labels[result.people]} · 次回は約12秒後`);
      if (candidate && this.canGreet()) {
        this.greet(greetingFor(result)); this.gate.greeted(Date.now());
        this.status('声をかけました · 人が映り続ける間は再挨拶しません');
      }
    } catch (e) { if (generation === this.generation) this.status(`画像確認: ${e.message}`); }
    finally { if (generation === this.generation) this.busy = false; }
  }
  stop() {
    ++this.generation; clearInterval(this.timer); this.timer = null;
    this.stream?.getTracks().forEach(t => t.stop()); this.stream = null;
    this.video.pause(); this.video.srcObject = null; this.canvas.width = this.canvas.height = 0;
    this.starting = false; this.busy = false; this.onActive(false); this.status('カメラOFF');
    // Keep the presence latch across toggles to avoid repeated greetings.
  }
}
