export function initPanels() {
  const sides=['left','right'];
  const panels={left:document.getElementById('leftPanel'),right:document.getElementById('rightPanel')};
  let timer;
  function set(side,open) {
    const p=panels[side]; p.classList.toggle('is-open',open); p.inert=!open;
    document.getElementById(side+'Edge').setAttribute('aria-expanded',String(open));
  }
  function open(side) {clearTimeout(timer); sides.forEach(s=>set(s,s===side));}
  function close() {clearTimeout(timer); sides.forEach(s=>set(s,false));}
  function later() {clearTimeout(timer); timer=setTimeout(()=>{if(!sides.some(s=>panels[s].contains(document.activeElement)))close();},550);}
  sides.forEach(side=>{
    const p=panels[side], trigger=document.getElementById(side+'Edge');p.inert=true;
    trigger.onclick=()=>p.classList.contains('is-open')?close():open(side);
    p.addEventListener('pointerenter',()=>clearTimeout(timer));
    p.addEventListener('pointerleave',later);
    p.addEventListener('focusin',()=>clearTimeout(timer));
    p.addEventListener('focusout',later);
    p.querySelector('[data-close]').onclick=()=>{document.activeElement?.blur();close();trigger.focus();};
  });
  window.addEventListener('pointermove',e=>{
    if(e.pointerType==='touch'||document.querySelector('dialog[open]'))return;
    if(e.clientX<24)open('left');
    else if(e.clientX>innerWidth-24)open('right');
    else if(!sides.some(s=>panels[s].contains(e.target)))later();
  });
  window.addEventListener('keydown',e=>{if(e.key==='Escape'&&!document.querySelector('dialog[open]')){document.activeElement?.blur();close();}});
  document.getElementById('fullscreen').onclick=()=>document.fullscreenElement?document.exitFullscreen():document.documentElement.requestFullscreen().catch(()=>{});
  document.getElementById('connect').addEventListener('click',()=>{if(!document.querySelector('dialog[open]')){document.activeElement?.blur();close();}});
}
