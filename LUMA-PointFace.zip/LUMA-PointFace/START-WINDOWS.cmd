@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 22 or later is required. Install Node.js LTS from https://nodejs.org/
  echo Then double-click START-WINDOWS.cmd again.
  pause
  exit /b 1
)
node -e "if(Number(process.versions.node.split('.')[0])<22)process.exit(1)"
if errorlevel 1 (
  echo Please update Node.js to version 22 or later: https://nodejs.org/
  pause
  exit /b 1
)
node server.mjs --open
pause
