import http from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { resolve, dirname, extname, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomBytes, timingSafeEqual } from 'node:crypto';
import { spawn } from 'node:child_process';

const ROOT = dirname(fileURLToPath(import.meta.url));
try { process.loadEnvFile(resolve(ROOT, '.env')); } catch (e) { if (e.code !== 'ENOENT') throw e; }
export const MODELS = ['gpt-realtime-mini', 'gpt-realtime-2.1', 'gpt-realtime'];
export const VOICES = ['marin', 'cedar', 'coral', 'verse'];

export function sessionConfig({ model, voice } = {}) {
  return {
    type: 'realtime', model: MODELS.includes(model) ? model : 'gpt-realtime-mini',
    output_modalities: ['audio'], max_output_tokens: 700,
    instructions: 'あなたはLUMA（ルマ）というデジタル人物のAIアシスタントです。自然で親しみやすい日本語で話してください。通常は2〜4文で簡潔に答え、必要なら詳しく説明してください。聞き取れないときは短く聞き返してください。あなたの声と人物表示はAIによるものです。カメラの観察が明示的に与えられた時だけ、見える服装・持ち物・動作に言及できます。映像は定期的な静止画であり、常時見ているとは言わないでください。人物の特定や年齢・性別・人種・健康・感情の推測はしないでください。ロボット操作は未接続です。実機を動かしたと主張しないでください。',
    audio: {
      input: {
        noise_reduction: { type: 'near_field' },
        transcription: { model: 'gpt-4o-mini-transcribe', language: 'ja' },
        turn_detection: { type: 'semantic_vad', eagerness: 'medium', create_response: true, interrupt_response: true },
      },
      output: { voice: VOICES.includes(voice) ? voice : 'marin' },
    },
  };
}

const mime = { '.html': 'text/html; charset=utf-8', '.css': 'text/css', '.js': 'text/javascript', '.mjs': 'text/javascript', '.json': 'application/json', '.glb': 'model/gltf-binary', '.bin': 'application/octet-stream', '.wav': 'audio/wav', '.svg': 'image/svg+xml' };
function json(res, status, data) { res.writeHead(status, { 'Content-Type': mime['.json'] }); res.end(JSON.stringify(data)); }
async function body(req) {
  let text = ''; let size = 0;
  for await (const chunk of req) { size += chunk.length; if (size > 131072) throw Object.assign(new Error('リクエストが大きすぎます。'), { status: 413 }); text += chunk; }
  try { return JSON.parse(text); } catch { throw Object.assign(new Error('JSON形式を確認してください。'), { status: 400 }); }
}
function sameSecret(actual, expected) {
  const a = Buffer.from(String(actual || '')); const b = Buffer.from(expected);
  return a.length === b.length && timingSafeEqual(a, b);
}
export function createApp({ fetchImpl = fetch, apiKey = process.env.OPENAI_API_KEY || '', publicRoot = resolve(ROOT, 'public') } = {}) {
  const csrf = randomBytes(32).toString('hex'); let pending = false;
  return http.createServer(async (req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('Referrer-Policy', 'no-referrer');
    res.setHeader('Permissions-Policy', 'camera=(self), microphone=(self)');
    const authority = req.headers.host || '';
    if (!/^(127\.0\.0\.1|localhost):\d+$/.test(authority)) return json(res, 403, { error: 'ローカル接続のみ利用できます。' });
    if (req.headers.origin && req.headers.origin !== `http://${authority}`) return json(res, 403, { error: '別のサイトからの接続は拒否しました。' });
    try {
      const url = new URL(req.url, `http://${authority}`);
      if (url.pathname === '/api/config' && req.method === 'GET') return json(res, 200, { hasKey: Boolean(apiKey), csrf, models: MODELS, voices: VOICES });
      if (url.pathname === '/api/session' && req.method === 'POST') {
        if (!sameSecret(req.headers['x-luma-token'], csrf)) return json(res, 403, { error: '画面を再読み込みしてください。' });
        if (!String(req.headers['content-type']).startsWith('application/json')) return json(res, 415, { error: 'JSONが必要です。' });
        const input = await body(req);
        const key = typeof input.apiKey === 'string' && input.apiKey.trim() ? input.apiKey.trim() : apiKey;
        if (!key) return json(res, 400, { error: '設定でOpenAI APIキーを入力してください。' });
        if (typeof input.sdp !== 'string' || !input.sdp.startsWith('v=0') || input.sdp.length > 100000) return json(res, 400, { error: '音声接続情報が不正です。' });
        if (pending) return json(res, 429, { error: '接続処理中です。少し待って再試行してください。' });
        pending = true;
        try {
          const fd = new FormData(); fd.set('sdp', input.sdp); fd.set('session', JSON.stringify(sessionConfig(input)));
          const upstream = await fetchImpl('https://api.openai.com/v1/realtime/calls', {
            method: 'POST', headers: { Authorization: `Bearer ${key}` }, body: fd, signal: AbortSignal.timeout(25000),
          });
          if (!upstream.ok) {
            const hints = { 400: 'モデル・音声設定が利用できない可能性があります。設定を変更してください。', 401: 'APIキーが無効です。入力を確認してください。', 403: 'このAPIキーではRealtime APIを利用できません。', 404: '選択したモデルが利用できません。別のモデルを選んでください。', 429: 'APIの残高・利用上限または接続頻度を確認してください。' };
            await upstream.text(); // Do not expose provider payloads or credentials.
            return json(res, upstream.status >= 500 ? 502 : upstream.status, { error: hints[upstream.status] || `OpenAI接続エラー（${upstream.status}）。時間をおいて再試行してください。` });
          }
          const sdp = await upstream.text();
          if (!sdp.startsWith('v=0')) return json(res, 502, { error: '音声接続の応答を読み取れませんでした。' });
          res.writeHead(200, { 'Content-Type': 'application/sdp' }); return res.end(sdp);
        } finally { pending = false; }
      }
      if (url.pathname.startsWith('/api/')) return json(res, 404, { error: 'Not found' });
      if (!['GET', 'HEAD'].includes(req.method)) return json(res, 405, { error: 'Method not allowed' });
      const relative = decodeURIComponent(url.pathname === '/' ? '/index.html' : url.pathname);
      const path = resolve(publicRoot, '.' + relative);
      if (!path.startsWith(publicRoot + sep)) return json(res, 403, { error: 'Forbidden' });
      const info = await stat(path);
      if (!info.isFile()) return json(res, 404, { error: 'Not found' });
      res.writeHead(200, { 'Content-Type': mime[extname(path)] || 'application/octet-stream', 'Content-Length': info.size });
      res.end(req.method === 'HEAD' ? undefined : await readFile(path));
    } catch (e) {
      if (res.headersSent) return res.end();
      const status = e.status || (e.code === 'ENOENT' ? 404 : 500);
      return json(res, status, { error: e.status ? e.message : e.name === 'TimeoutError' ? 'OpenAI接続がタイムアウトしました。ネットワークを確認してください。' : status === 404 ? 'Not found' : '接続できませんでした。ネットワークまたは設定を確認してください。' });
    }
  });
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const port = Number(process.env.PORT || 8787);
  const server = createApp();
  server.on('error', e => { console.error(e.code === 'EADDRINUSE' ? `Port ${port} is in use. Close the other LUMA window or change PORT in .env.` : e.message); process.exitCode = 1; });
  server.listen(port, '127.0.0.1', () => {
    const url = `http://127.0.0.1:${port}`;
    console.log(`\nLUMA is ready: ${url}\nKeep this window open. Ctrl+C to stop.\n`);
    if (process.argv.includes('--open') && process.platform === 'win32') spawn('cmd.exe', ['/c', 'start', '', url], { stdio: 'ignore' }).on('error', () => {});
  });
}
