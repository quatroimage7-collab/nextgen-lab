import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createApp } from '../server.mjs';

async function fixture(t, options = {}) {
  const app = createApp({ apiKey: '', ...options });
  await new Promise(resolve => app.listen(0, '127.0.0.1', resolve));
  t.after(() => new Promise(resolve => app.close(resolve)));
  const base = `http://127.0.0.1:${app.address().port}`;
  const config = await (await fetch(base + '/api/config')).json();
  return {
    base, config,
    post: (data, headers = {}) => fetch(base + '/api/session', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Luma-Token': config.csrf, ...headers }, body: JSON.stringify(data) }),
  };
}
test('UI and bundled files are served; secrets are not exposed', async t => {
  const f = await fixture(t, { apiKey: 'secret-not-for-browser' });
  assert.equal(f.config.hasKey, true); assert.equal(JSON.stringify(f.config).includes('secret-not-for-browser'), false);
  assert.equal((await fetch(f.base + '/')).status, 200);
  assert.equal((await fetch(f.base + '/.env')).status, 404);
  assert.equal((await fetch(f.base + '/server.mjs')).status, 404);
  assert.equal((await fetch(f.base + '/vendor/headworklet.mjs')).status, 200);
});
test('missing key and malformed SDP are actionable errors', async t => {
  const f = await fixture(t);
  let r = await f.post({ sdp: 'v=0' }); assert.equal(r.status, 400); assert.match((await r.json()).error, /APIキー/);
  r = await f.post({ sdp: '<html>', apiKey: 'test' }); assert.equal(r.status, 400);
});
test('rejects other origins and missing session token', async t => {
  const f = await fixture(t);
  assert.equal((await f.post({ sdp: 'v=0', apiKey: 'test' }, { Origin: 'https://evil.example' })).status, 403);
  assert.equal((await f.post({ sdp: 'v=0', apiKey: 'test' }, { 'X-Luma-Token': 'invalid' })).status, 403);
});
test('real session proxy produces documented multipart contract with Japanese ASR', async t => {
  let captured;
  const f = await fixture(t, { fetchImpl: async (url, options) => { captured = { url, options }; return new Response('v=0\r\ns=answer\r\n', { status: 201 }); } });
  const r = await f.post({ sdp: 'v=0\r\ns=offer\r\n', apiKey: 'test-secret', voice: 'marin', model: 'gpt-realtime-mini' });
  assert.equal(r.status, 200); assert.match(await r.text(), /^v=0/);
  assert.equal(captured.url, 'https://api.openai.com/v1/realtime/calls');
  assert.equal(captured.options.headers.Authorization, 'Bearer test-secret');
  const session = JSON.parse(captured.options.body.get('session'));
  assert.equal(session.audio.input.transcription.language, 'ja');
  assert.equal(session.audio.input.turn_detection.interrupt_response, true);
  assert.deepEqual(session.output_modalities, ['audio']);
});
test('provider failures hide provider payload and key', async t => {
  const f = await fixture(t, { fetchImpl: async () => new Response('secret-provider-error', { status: 401 }) });
  const r = await f.post({ sdp: 'v=0', apiKey: 'test' });
  assert.equal(r.status, 401); const text = await r.text(); assert.match(text, /APIキー/); assert.equal(text.includes('secret-provider-error'), false);
});
test('path traversal and invalid JSON are rejected', async t => {
  const f = await fixture(t);
  assert.equal((await fetch(f.base + '/%2e%2e%2fserver.mjs')).status, 403);
  const r = await fetch(f.base + '/api/session', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Luma-Token': f.config.csrf }, body: 'broken' });
  assert.equal(r.status, 400);
});
