// Start `node server.mjs` before this test. Live OpenAI access is NOT used.
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || 'playwright');
const assert = require('node:assert/strict');
const path = require('node:path');
const fs = require('node:fs');
const root = path.resolve(__dirname, '..');
const fixture = path.join(__dirname, 'fixtures/formants.wav');

(async () => {
  let executablePath = process.env.CHROME_PATH;
  if (process.env.SPARTICUZ_MODULE) {
    const chrome = require(process.env.SPARTICUZ_MODULE);
    if (process.env.TEST_JAPANESE_FONT) await chrome.font(process.env.TEST_JAPANESE_FONT);
    executablePath = await chrome.executablePath();
  }
  const browser = await chromium.launch({ executablePath, headless: true, args: ['--no-sandbox', '--enable-unsafe-swiftshader', '--autoplay-policy=no-user-gesture-required', '--use-fake-ui-for-media-stream', '--use-fake-device-for-media-stream'] });
  const errors = []; const results = [];
  const page = await browser.newPage({ viewport: { width: 1440, height: 940 }, permissions: ['microphone', 'camera'] });
  page.on('pageerror', error => errors.push(error.message));
  page.on('console', msg => { if (msg.type() === 'error' && /THREE|GLSL|shader/i.test(msg.text())) errors.push(msg.text()); });
  const click = async selector => {
    const panel = await page.locator(selector).evaluate(el => el.closest('.edge-panel')?.id);
    if (panel) { const w=page.viewportSize().width; await page.mouse.move(panel==='leftPanel'?2:w-2,300); await page.waitForTimeout(320); }
    await page.locator(selector).click();
  };
  const snapshot = () => page.evaluate(async () => (await import('/app.js')).diagnosticSnapshot());
  try {
    await page.goto(process.env.TEST_URL || 'http://127.0.0.1:8787');
    await page.waitForFunction(() => document.documentElement.dataset.ready === 'true', null, { timeout: 40000 });
    assert.equal((await snapshot()).pointCount, 18000);
    results.push('PASS: reference artwork displayed with GPU mouth deformation; internal rig ready');
    await page.waitForTimeout(700);
    await page.screenshot({ path: path.join(root, 'docs/preview.png') });
    const idleA=await page.locator('.reference-canvas').screenshot();
    const clockA=(await snapshot()).ambientTime;
    await page.waitForTimeout(1600);
    const idleB=await page.locator('.reference-canvas').screenshot();
    assert.ok((await snapshot()).ambientTime>clockA+1);
    assert.equal(idleA.equals(idleB),false);
    assert.equal((await snapshot()).connected,false);
    results.push('PASS: idle artwork changes without API connection or microphone activation');

    assert.equal(await page.locator('#leftPanel').evaluate(e => e.inert), true);
    assert.equal(await page.locator('#rightPanel').evaluate(e => e.inert), true);
    await page.mouse.move(2,300); await page.waitForTimeout(350);
    assert.equal(await page.locator('#leftPanel').evaluate(e => e.inert), false);
    await page.mouse.move(720,300); await page.waitForTimeout(900);
    assert.equal(await page.locator('#leftPanel').evaluate(e => e.inert), true);
    await page.mouse.move(1438,300); await page.waitForTimeout(350);
    assert.equal(await page.locator('#rightPanel').evaluate(e => e.inert), false);
    await page.screenshot({path:path.join(root,'docs/preview-sidebar.png')});
    await page.mouse.move(720,300); await page.waitForTimeout(900);
    assert.equal(await page.locator('#rightPanel').evaluate(e => e.inert), true);
    results.push('PASS: both edge-hover panels open, close on leaving, and do not resize artwork');

    await click('#connect'); assert.equal(await page.locator('#settings').evaluate(e => e.open), true);
    await page.fill('#apiKey', 'test-invalid-key'); await click('#applySettings');
    await page.route('**/api/session', route => route.fulfill({ status: 401, contentType: 'application/json', body: JSON.stringify({ error: 'APIキーが無効です。' }) }));
    await click('#connect');
    await page.waitForFunction(() => document.querySelector('#notice').textContent.includes('APIキーが無効'));
    assert.equal((await snapshot()).micTracks.length, 0); assert.equal(await page.inputValue('#apiKey'), '');
    results.push('PASS: invalid-key message, secret cleared, microphone released');
    await page.unroute('**/api/session');

    await click('#diagnosticsButton');
    await page.setInputFiles('#audioFile', fixture);
    let peak = 0, renderedPeak = 0;
    for (let i = 0; i < 16; i++) { await page.waitForTimeout(200); const s = await snapshot(); peak = Math.max(peak, ...Object.values(s.visemes)); renderedPeak = Math.max(renderedPeak,s.renderedMouth); }
    assert.ok(peak > .05, 'Audio must drive nonzero mouth morph targets'); assert.ok(renderedPeak>.02, 'Sphere must react to playback');
    await page.waitForFunction(() => document.querySelector('#captionLabel').textContent === 'TEST COMPLETE', null, { timeout: 10000 });
    results.push(`PASS: actual Web Audio → HeadAudio → mouth deformation (peak ${peak.toFixed(3)})`);
    await click('#diagnosticsButton'); await click('#recordTest');
    await page.waitForFunction(() => document.querySelector('#testStatus').textContent.includes('録音中'));
    await page.waitForFunction(() => document.querySelector('#captionLabel').textContent === 'TEST COMPLETE' && document.querySelector('#status').textContent === '待機中', null, { timeout: 16000 });
    results.push('PASS: microphone record → decode → replay → local lipsync (Chromium synthetic microphone)');

    // A second real RTCPeerConnection replaces only the remote service in this test.
    // This exercises actual SDP, media tracks, DataChannel, interruption and teardown.
    await page.route('**/test-formants.wav', route => route.fulfill({ path: fixture, contentType: 'audio/wav' }));
    await page.route('**/api/session', async route => {
      const input = route.request().postDataJSON();
      const answer = await page.evaluate(async sdp => {
        const pc = new RTCPeerConnection(); window.testRemote = pc; window.testEvents = [];
        const ctx = new AudioContext(); await ctx.resume(); window.testAudioContext = ctx;
        const dst = ctx.createMediaStreamDestination(); const source = ctx.createBufferSource();
        source.buffer = await ctx.decodeAudioData(await (await fetch('/test-formants.wav')).arrayBuffer()); source.loop = true; source.connect(dst); source.start(); window.testSource = source;
        dst.stream.getTracks().forEach(t => pc.addTrack(t, dst.stream));
        pc.ondatachannel = ev => {
          const dc = ev.channel; window.testChannel = dc;
          dc.onmessage = ev => {
            const event = JSON.parse(ev.data); window.testEvents.push(event);
            if (event.type === 'response.create' && event.response?.metadata?.topic === 'camera') {
              const response = {id: 'vision-' + event.event_id, metadata: event.response.metadata};
              dc.send(JSON.stringify({type:'response.created', response}));
              const result = {people:window.testPresence || 'one', clothing:'blue', object:'bag', action:'standing'};
              setTimeout(() => { if(dc.readyState==='open') dc.send(JSON.stringify({type:'response.done', response:{...response,status:'completed',output:[{type:'message',content:[{type:'output_text',text:JSON.stringify(result)}]}]}})); }, window.testVisionDelay || 0);
              return;
            }
            if (event.type === 'response.create') {
              dc.send(JSON.stringify({ type: 'response.created', response: { id: 'response-test' } }));
              dc.send(JSON.stringify({ type: 'output_audio_buffer.started' }));
              dc.send(JSON.stringify({ type: 'conversation.item.input_audio_transcription.delta', item_id: 'user-test', delta: 'こんにちは。' }));
              dc.send(JSON.stringify({ type: 'conversation.item.input_audio_transcription.completed', item_id: 'user-test', transcript: 'こんにちは。テストです。' }));
              dc.send(JSON.stringify({ type: 'response.output_audio_transcript.delta', item_id: 'ai-test', delta: 'こんにちは。' }));
              dc.send(JSON.stringify({ type: 'response.output_audio_transcript.done', item_id: 'ai-test', transcript: 'こんにちは。音声接続のテストです。' }));
            }
            if (event.type === 'output_audio_buffer.clear') dc.send(JSON.stringify({ type: 'output_audio_buffer.cleared' }));
          };
        };
        await pc.setRemoteDescription({ type: 'offer', sdp }); await pc.setLocalDescription(await pc.createAnswer());
        if (pc.iceGatheringState !== 'complete') await new Promise(resolve => { pc.onicegatheringstatechange = () => { if (pc.iceGatheringState === 'complete') resolve(); }; });
        return pc.localDescription.sdp;
      }, input.sdp);
      await route.fulfill({ status: 200, contentType: 'application/sdp', body: answer });
    });
    await click('#settingsButton'); await page.fill('#apiKey', 'test-key-local-peer'); await click('#applySettings');
    await click('#connect');
    await page.waitForFunction(() => document.querySelector('#caption').textContent.includes('音声接続のテスト'), null, { timeout: 25000 });
    let remotePeak = 0;
    for (let i = 0; i < 15; i++) { await page.waitForTimeout(150); const s = await snapshot(); remotePeak = Math.max(remotePeak, ...Object.values(s.visemes)); }
    assert.ok(remotePeak > .05); assert.equal((await snapshot()).connected, true);
    assert.ok((await page.locator('#transcript').textContent()).includes('こんにちは。テストです。'));
    await click('#mute'); assert.equal((await snapshot()).micTracks[0].enabled, false);
    await click('#mute'); assert.equal((await snapshot()).micTracks[0].enabled, true);
    await page.mouse.move(1438,300); await page.waitForTimeout(350); await page.fill('#textInput', '文字入力の確認'); await click('#send');
    await page.waitForFunction(() => window.testEvents.some(e => e.type === 'conversation.item.create'));
    await click('#interrupt');
    assert.ok(await page.evaluate(() => window.testEvents.some(e => e.type === 'output_audio_buffer.clear')));
    // Camera uses synthetic Chromium video and mocked vision ONLY; no live AI claims.
    await page.waitForTimeout(15500);
    await page.evaluate(() => { window.testPresence = 'none'; });
    await click('#cameraToggle');
    await page.waitForFunction(() => document.querySelector('#cameraStatus').textContent.includes('人は映っていません'));
    assert.equal((await snapshot()).cameraActive,true);
    assert.equal(await page.locator('#cameraIndicator').isVisible(),true);
    assert.equal((await snapshot()).state,'listening');
    const countGreetings = () => page.evaluate(() => window.testEvents.filter(e => e.type==='response.create' && e.response?.instructions?.includes('カメラの直近')).length);
    assert.equal(await countGreetings(),0);
    await page.evaluate(() => { window.testPresence = 'one'; });
    await click('#cameraCheck');
    await page.waitForFunction(() => window.testEvents.some(e => e.response?.instructions?.includes('カメラの直近')));
    assert.equal(await countGreetings(),1);
    await click('#interrupt'); await click('#cameraCheck');
    await page.waitForTimeout(500);
    assert.equal(await countGreetings(),1);
    const frames = await page.evaluate(() => window.testEvents.filter(e => e.response?.metadata?.topic==='camera').map(e => e.response.input[0].content[0].image_url.length));
    assert.ok(frames.length >= 3 && frames.every(n => n < 44000));
    assert.ok(!(await page.locator('#transcript').textContent()).includes('clothing'));
    await page.screenshot({path:path.join(root,'docs/preview-camera.png')});
    // Start a delayed vision response, then stop. It must not change state or speak.
    await page.evaluate(() => { window.testVisionDelay = 1000; window.savedCameraTrack = document.querySelector('#cameraPreview').srcObject.getVideoTracks()[0]; });
    await click('#cameraCheck');
    await page.waitForFunction(() => document.querySelector('#cameraStatus').textContent.includes('確認しています'));
    await click('#cameraStop');
    await page.waitForTimeout(1200);
    assert.equal((await snapshot()).cameraActive,false);
    assert.equal((await snapshot()).state,'listening');
    assert.equal(await page.evaluate(() => window.savedCameraTrack.readyState),'ended');
    assert.equal(await countGreetings(),1);
    assert.equal(await page.locator('#cameraIndicator').isVisible(),false);
    results.push('PASS: camera preview/permission, bounded JPEG over WebRTC, isolated observation, no-person silence, feature greeting, repeat suppression, late-result discard, camera track release');
    await click('#connect'); assert.equal((await snapshot()).connected, false); assert.equal((await snapshot()).sourceCount, 0); assert.equal((await snapshot()).micTracks.length, 0);
    await page.evaluate(() => { window.testRemote.close(); window.testSource.stop(); window.testAudioContext.close(); });
    results.push(`PASS: real local WebRTC/SDP/remote audio + Japanese subtitle events; mouth peak ${remotePeak.toFixed(3)}`);
    results.push('PASS: microphone mute/unmute, text input, cancel/clear events, session teardown');
    await page.setViewportSize({ width: 390, height: 844 });
    assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
    results.push('PASS: narrow-screen layout');
    assert.deepEqual(errors, []);
    results.push('PASS: no uncaught JS / WebGL shader errors');
    results.push('NOT TESTED: live OpenAI image/audio API, real passerby recognition, Windows hardware camera/microphone/speaker, Japanese conversational accuracy, human-rated lip-sync naturalness.');
    fs.writeFileSync(path.join(root, 'docs/browser-test-results.txt'), results.join('\n') + '\n');
    console.log(results.join('\n'));
  } finally { await browser.close(); }
})().catch(e => { console.error(e); process.exitCode = 1; });
