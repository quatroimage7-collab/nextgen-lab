const {chromium}=require(process.env.PLAYWRIGHT_MODULE || 'playwright');
const assert=require('node:assert/strict');
const fs=require('node:fs');
(async()=>{
 const chrome=require(process.env.SPARTICUZ_MODULE || '@sparticuz/chromium');
 if(process.env.TEST_JAPANESE_FONT) await chrome.font(process.env.TEST_JAPANESE_FONT);
 const browser=await chromium.launch({executablePath:process.env.CHROME_PATH || await chrome.executablePath(),headless:true,args:['--no-sandbox','--enable-unsafe-swiftshader','--autoplay-policy=no-user-gesture-required']});
 try{
 const page=await browser.newPage({viewport:{width:1440,height:810}});const errors=[];
 page.on('pageerror',e=>errors.push(e.message));
 page.on('console',m=>{if(m.type()==='error' && /shader|GLSL|THREE/.test(m.text()))errors.push(m.text());});
 const imageRequests=[];page.on('request',r=>{if(/images\//.test(r.url()))imageRequests.push(r.url());});
 const snap=()=>page.evaluate(async()=>(await import('/app.js')).diagnosticSnapshot());
 await page.goto('http://127.0.0.1:8787');await page.waitForFunction(()=>document.documentElement.dataset.ready==='true',null,{timeout:40000});
 const idleBounce=[]; const scales=[];for(let i=0;i<8;i++){const idle=await snap(); scales.push(idle.sphereScale);idleBounce.push(idle.bounceY);await page.waitForTimeout(500);}const b=await snap();
 assert.equal(b.displayMode,'particles-3d');assert.equal(b.connected,false);assert.ok(Math.max(...scales)-Math.min(...scales)>.01);
 assert.ok(Math.max(...idleBounce)-Math.min(...idleBounce)>.006);
 assert.deepEqual(b.particleCounts,{sphere:18000,background:12600,rings:1500});assert.deepEqual(imageRequests,[]);
 const backgroundA=await page.screenshot({clip:{x:40,y:80,width:240,height:500}});
 await page.waitForTimeout(800);
 const backgroundB=await page.screenshot({clip:{x:40,y:80,width:240,height:500}});
 assert.equal(backgroundA.equals(backgroundB),false,'Background particles must move independently');
 await page.screenshot({path:'docs/preview.png'});
 await page.mouse.move(2,300);await page.waitForTimeout(400);await page.click('#diagnosticsButton');
 await page.setInputFiles('#audioFile','tests/fixtures/formants.wav');
 let max=0, energy=0, bounce=0;
 for(let i=0;i<12;i++){await page.waitForTimeout(180);const d=await snap();max=Math.max(max,d.sphereScale);energy=Math.max(energy,d.audioEnergy);bounce=Math.max(bounce,d.bounceY);}
 assert.ok(max>1.10,`sphere should grow appreciably with playback; got ${max}`);assert.ok(energy>.1);assert.ok(bounce>.025);
 await page.mouse.move(720,300);await page.waitForTimeout(700);
 await page.screenshot({path:'docs/preview-speaking.png'});
 await page.waitForFunction(()=>document.querySelector('#captionLabel').textContent==='TEST COMPLETE');
 await page.waitForTimeout(1300);assert.ok((await snap()).audioEnergy<.02);
 await page.emulateMedia({reducedMotion:'reduce'});await page.waitForTimeout(150);assert.equal((await snap()).sphereScale,1);assert.equal((await snap()).bounceY,0);
 await page.setViewportSize({width:390,height:844});assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
 assert.deepEqual(errors,[]);
 const report=`PASS: 3D particle sphere (18,000) and background (14,100) render without any image request; background pixels animate\nPASS: actual playback audio drives scale to ${max.toFixed(3)} (energy ${energy.toFixed(3)})\nPASS: idle bounce and stronger audio-driven bounce (peak ${bounce.toFixed(3)} image height)\nPASS: playback end returns energy to idle\nPASS: reduced-motion freezes scale; narrow layout has no overflow\nPASS: no uncaught JavaScript errors\nNOT TESTED: Windows hardware or live OpenAI service (unchanged).\n`;
 fs.writeFileSync('docs/sphere-test-results.txt',report);console.log(report);
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
